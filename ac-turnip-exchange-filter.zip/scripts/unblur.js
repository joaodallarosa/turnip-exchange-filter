(function () {
  document.getElementById('app').style.filter = 'none';
})();
