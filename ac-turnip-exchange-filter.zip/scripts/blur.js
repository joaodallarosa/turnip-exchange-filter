(function () {
  document.getElementById('app').style.filter = 'blur(5px)';
})();
